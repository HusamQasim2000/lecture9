﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec9
{
    public partial class updateform : Form
    {
        public string number { get; private set; }
        public string names { get; private set; }
        public string ages { get; private set; }
        public string sex { get; private set; }

        public updateform(string num, string name, string age, string faml)

        {
            InitializeComponent();
            // تعبئة الحقول بالبيانات الحالية
            textBox1.Text = num;
            textBox2.Text = name;
            textBox3.Text = age;
            if (faml == radioButton1.Text)
                radioButton1.Checked = true;
            else if (faml == radioButton2.Text)
                radioButton2.Checked = true;

        }
        public updateform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
            
        {
            number = textBox1.Text;
            names = textBox2.Text;
            ages = textBox3.Text;
            if (radioButton1.Checked)
                sex = radioButton1.Text;
            else if (radioButton2.Checked)
                sex = radioButton2.Text;
            DialogResult = DialogResult.OK; // إغلاق النافذة مع نجاح العملية
        }
    }
}
