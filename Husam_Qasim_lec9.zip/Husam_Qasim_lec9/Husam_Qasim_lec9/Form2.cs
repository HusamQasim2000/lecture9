﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec9
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = listBox1.Items.Count - 1;
            listBox1.SelectedIndex = a;
            listBox2.SelectedIndex = a;
            listBox3.SelectedIndex = a;
            listBox4.SelectedIndex = a;
            if (textBox1.Text != " " && textBox2.Text != " " && textBox3.Text != " " && radioButton1.Checked || radioButton2.Checked)
            {
                listBox1.Items.Add(textBox1.Text);
                listBox2.Items.Add(textBox2.Text);
                listBox3.Items.Add(textBox3.Text);
                if (radioButton1.Checked)
                    listBox4.Items.Add(radioButton1.Text);
                else
                    listBox4.Items.Add(radioButton2.Text);
            }
            else
                MessageBox.Show("يوجد حقل فارغ");
            textBox1.Text = textBox2.Text = textBox3.Text = " ";
            radioButton1.Checked = radioButton2.Checked = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = listBox1.SelectedIndex;
            listBox2.SelectedIndex = a;
            listBox3.SelectedIndex = a;
            listBox4.SelectedIndex = a;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = listBox1.SelectedIndex;
            if (a > -1)
            {
                listBox1.Items.RemoveAt(a);
                listBox2.Items.RemoveAt(a);
                listBox3.Items.RemoveAt(a);
                listBox4.Items.RemoveAt(a);
            }
            else
                MessageBox.Show("selected item");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                listBox1.Items.Clear(); listBox2.Items.Clear(); listBox3.Items.Clear(); listBox4.Items.Clear();
            }
            else
                MessageBox.Show("empty");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex == -1)
            {
                MessageBox.Show("يرجى تحديد طالب لتعديله", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // الحصول على البيانات الحالية
            string d = listBox4.SelectedItem.ToString();
            string c = listBox1.SelectedItem.ToString();
            string b = listBox2.Items[selectedIndex].ToString();
            string a = listBox3.Items[selectedIndex].ToString();


            // فتح نافذة التعديل
            updateform f = new updateform(a, b, c, d);
            if (f.ShowDialog() == DialogResult.OK)
            {
                // تحديث البيانات في القوائم
                listBox1.Items[selectedIndex] = f.number;
                listBox2.Items[selectedIndex] = f.names;
                listBox3.Items[selectedIndex] = f.ages;
                listBox4.Items[selectedIndex] = f.sex;
            }
        }
    }
}
