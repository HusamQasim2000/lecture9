﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            setenabled();
            Height = groupBox1.Top + 40;
            Random r = new Random();
            for( int x=0; x < 10; x++)
            {
                int n = r.Next(100);
                listBox1.Items.Add(n);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isNumoric(textBox1.Text.Trim()))
            {
                if (!repeated(listBox1, textBox1.Text))
                {
                    listBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("يجب ان يكون المدخل رقما");
                    textBox1.Clear();
                    textBox1.Focus();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int c = listBox1.SelectedItems.Count;
            for(int i=0; i< c; i++)
            {
                if (!repeated(listBox2, listBox1.SelectedItems[0].ToString()))
                {
                    listBox2.Items.Add(listBox1.Items[listBox1.SelectedIndex]);
                    listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
        // transfer of reverse items
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            int n=listBox1.Items.Count;
            for(int i=0; i< n; i++)
            {
                listBox2.Items.Add(listBox1.Items.Count - 1);
                listBox1.Items.Remove(listBox1.Items[listBox1.Items.Count - 1]);
            }
        }
        //زرترتيب العناصر تنازليا-القائمة الاولى
        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            sortAnylistbox(listBox1);
            //sortAnylistbox((listBox1)sender);
        }
        //زر عكس عناصر - القائمة الاولى
        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox1);
        }
        //even
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            //int n=int.Parse(listBox1.Items[0]);
            if (radioButtoneven.Checked){
                    for(int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 == 0)
                        listBox1.SelectedIndex = i;
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("لا يوجد عناصر زوجية");
                }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            //int n=int.Parse(listBox1.Items[0]);
            if (radioButtonodd.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 != 0)
                        listBox1.SelectedIndex = i;
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("لا يوجد عناصر فردي");
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            bool falg = true;
            if (radioButton3.Checked)
            {
                for(int i = 0; i < listBox1.Items.Count; i++)
                {
                    int n = Convert.ToInt32(listBox1.Items[i]);
                    falg= true;
                    for (int j = 2; j < n / 2; j++)
                    {
                        if (n % j == 0) { falg = false; break; }
                    }
                        if (falg == true)
                            listBox1.SelectedIndex = i;
                    }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("الايوجد عناصر اولية");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text == "v")
            {
                Height = button3.Top + button3.Height + 50;
                button4.Text = "^";
            }
            else{
                button4.Text = "v";
                Height = groupBox1.Top + 40;
            }
        }
        //جذف عنصر مظلل من القائمة الاولى
        private void button8_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            //او بالطريقة الثانية بدون شرط
            //listBox1.Items.Remove(listBox1.SelectedItem);
        }
        private void sortAnylistbox(ListBox l)
        {
            int t; int c = l.Items.Count;
            for(int i = 0; i < c; i++)
            {
                int m = i;
                for (int j = i+1; j < c; j++){

                    int n1 = Convert.ToInt32(l.Items[m]);
                    int n2 = Convert.ToInt32(l.Items[j]);
                   if (Convert.ToInt32(l.Items[m])< Convert.ToInt32(l.Items[j]))
                    { m = j;
                        t = n1;
                        l.Items[i] = n2;
                        l.Items[m] = t;

                    }
            }
            }
        }
        //reverse lelemen list2
        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox2);
        }
        //sorted element list2
        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            sortAnylistbox(listBox2);
        }
        //تظليل عنصر
        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Add(textBox2.Text);
        }
        //ازلة التظليل على العنصر
        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Remove(textBox3.Text);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            textBox5.Text = listBox1.Items.Count.ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox6.Text = listBox1.SelectedItems.Count.ToString();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox7.Text = (listBox1.Items.Count - listBox1.SelectedItems.Count).ToString();
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    listBox1.SelectedIndex = i;
                }
            }
            else
                MessageBox.Show("not found element");
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
        }
        bool repeated(ListBox l,string s)
        {
            for(int i = 0; i < l.Items.Count; i++)
            {
                if (l.Items[i].ToString() == s)
                    return true;
            }
            return false;
        }
        void setenabled()
        {
            button2.Enabled = listBox1.SelectedIndex > -1;
        }
        void revers(ListBox l)
        {
            for(int i = l.Items.Count; i >=0; i++)
            {
                l.Items.Add(l.Items[i]);
                l.Items.Remove(l.Items[i]);
            }
        }
        bool isNumoric(string el)
        {
            if (el == "") return false;
            for(int i = 0; i < el.Length; i++)
            {
                if (el[i] < 48 || el[i] > 57)
                    return false;
            }
            return true;
        }

    }
}
